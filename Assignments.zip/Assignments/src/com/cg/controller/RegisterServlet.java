package com.cg.controller;

import java.io.IOException;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.User;
import com.cg.exception.UserException;
import com.cg.service.UserService;
import com.cg.service.UserServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RegisterServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserService userv=new UserServiceImpl();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String pwd=request.getParameter("pwd");
		String gen=request.getParameter("gen");
		String[] skill=request.getParameterValues("skill");
		String skillset=String.join("," ,skill);
		String city=request.getParameter("city");
		
		User user=new User();
		user.setFirstName(fname);
		user.setLastName(lname);
		user.setPassword(pwd);
		user.setGender(gen);
		user.setSkill(skillset);
		user.setCity(city);
		
		try {
			int dataAdded=userv.registerUser(user);
			if(dataAdded==1)
			{
				response.sendRedirect("RegistartionSuccess.html");
			}
			else
			{
				response.sendRedirect("RegistartionFailure.html");
			}
			
		} catch (UserException e) {
			
			e.printStackTrace();
		}
	}

}
