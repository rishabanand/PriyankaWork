package com.cg.spring.controller;

import java.time.LocalDate;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.bean.Employee;

@Controller
public class BasicController {
	
	@RequestMapping("/redirectToController")
	public String displayRegisterInformation(Model model)
	{
		Employee employee=new Employee();
		model.addAttribute("employee",employee);
		return "Registration";
	}
	
	@RequestMapping("/postPersonDetails")
	
		public String getPersonDetails(Model model,@Valid @ModelAttribute("employee")  Employee employee,BindingResult result )
		{
		if(result.hasErrors())
		{
			return "Registration";
		}
		else
		{
			model.addAttribute("employee",employee);
			return "ShowName";
		}
		}
	
//	@RequestMapping("/redirectToJspPage")
//	public String displayDate(Model model)
//	{
//		LocalDate today=LocalDate.now();
//		model.addAttribute("date",today);
//		return "ShowDate";
//	}
//	@RequestMapping("postData.obj")
//	public String getUserName(Model model, @RequestParam("username") String uname)
//	{
//		model.addAttribute("user",uname);
//		return "ShowName";
//	}


}
