package com.cg.springboot.pl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.spring.bean.Employee;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.cg.spring")
public class Client {
	public static void main(String[] args) {
		
		ApplicationContext context=SpringApplication.run(Client.class);
		Employee emp=(Employee) context.getBean("emp");
		emp.printMessage();
	}

}
