package com.cg.dto;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;

public class Employee {
	private String name;
	private int empid;
	private LocalDate doj;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public LocalDate getDoj() {
		return doj;
	}
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", doj=" + doj
				+ "]";
	}
	

}
