package com.cg.spring.util;
import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;



public class DateEditor extends PropertyEditorSupport {
	
	public DateEditor()
	{
		
	}

	@Override
	
	public void setAsText(String text) throws IllegalArgumentException{
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date=LocalDate.parse(text,format);
		setValue(date);
	}
}
