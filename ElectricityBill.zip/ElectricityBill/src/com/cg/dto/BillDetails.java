package com.cg.dto;

import java.time.LocalDate;

public class BillDetails {
	private int billNo;
	private int consumerNo;
	private double curReading;
	public int getBillNo() {
		return billNo;
	}

	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	
	public BillDetails(int consumerNo,double curReading,double unitCon,double netAmt){
		super();
		this.consumerNo = consumerNo;
		this.curReading = curReading;
		this.unitCon = unitCon;
		this.netAmt=netAmt;
		
	}

	public BillDetails(int billNo, int consumerNo, double curReading,
			double unitCon, double netAmt, LocalDate billDate) {
		super();
		this.billNo = billNo;
		this.consumerNo = consumerNo;
		this.curReading = curReading;
		this.unitCon = unitCon;
		this.netAmt = netAmt;
		this.billDate = billDate;
	}

	public int getConsumerNo() {
		return consumerNo;
	}

	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}

	public double getCurReading() {
		return curReading;
	}

	public void setCurReading(double curReading) {
		this.curReading = curReading;
	}

	public double getUnitCon() {
		return unitCon;
	}

	public void setUnitCon(double unitCon) {
		this.unitCon = unitCon;
	}

	public double getNetAmt() {
		return netAmt;
	}

	public void setNetAmt(double netAmt) {
		this.netAmt = netAmt;
	}

	public LocalDate getBillDate() {
		return billDate;
	}

	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}

	private double unitCon;
	private double netAmt;
	private LocalDate billDate;

	public BillDetails() {
	
	}

}
