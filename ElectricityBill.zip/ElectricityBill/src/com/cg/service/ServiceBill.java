package com.cg.service;

import com.cg.dto.BillDetails;
import com.cg.dto.Customer;
import com.cg.exception.BillException;

public interface ServiceBill {
	
	int addBillDetails(BillDetails bill) throws BillException;
	Customer getCustomerDetails(int cid) throws BillException;

}
