package com.cg.dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.cg.dto.BillDetails;
import com.cg.dto.Customer;
import com.cg.exception.BillException;


public class BillDaoImpl implements BillDao  {
	Connection conn;

	public BillDaoImpl() {
		
	}

	@Override
	public int addBillDetails(BillDetails bill) throws BillException {
		
		String sql="INSERT INTO BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(seq_bill_num.nextval,?,?,?,?,?)";
		int ct=0;
		try {
			conn=DBUtil.getConnection();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, bill.getConsumerNo());
			pst.setDouble(2,bill.getCurReading());
			pst.setDouble(3,bill.getUnitCon());
			pst.setDouble(4,bill.getNetAmt());
			LocalDate billdate=LocalDate.now();
			pst.setDate(5,Date.valueOf(billdate));
			ct=pst.executeUpdate();
			int r=pst.executeUpdate();
			int billid=0;
			if(r==1)
			{
			Statement st=conn.createStatement();
			 ResultSet rst=st.executeQuery("select seq_bill_num.currval from dual");
			 if(rst.next())
			 
				 billid=rst.getInt(1);
			 
			}
		} catch (SQLException e) 
		{
			throw new BillException("Customer Id does Not exist");
			
		}
		
		return ct;

		}

	@Override
	public Customer getCustomerDetails(int cid) throws BillException {
		String sql="SELECT * FROM consumers WHERE consumer_num=?";
		Customer cust=new Customer();
		
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,cid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				
				cust.setConsumerNo(rst.getInt("consumer_num"));
				cust.setConsumerName(rst.getString("consumer_name"));
				cust.setAddress(rst.getString("address"));
				
			}
		} catch (SQLException e) {
			throw new BillException("Problem in fetching mobile data");
		}
		return cust ;
	}

	
}


