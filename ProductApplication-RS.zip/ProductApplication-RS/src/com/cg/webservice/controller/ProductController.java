package com.cg.webservice.controller;

import java.util.ArrayList;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.webservice.bean.Product;

@Path(value="/products")
public class ProductController {

	
	@Path(value="/ListAllProducts")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Product> getProductList(){
		System.out.println("in product list ");
		
		ArrayList<Product> list= new ArrayList<>();
		list.add(new Product(102, "Laptop", 343333));
		list.add(new Product(103, "Adaptor", 343333));
		list.add(new Product(104, "iPad", 343333));
		
		return list;
	}
	
	@POST
	@Path(value="/addProduct")
	public void addProductDetails(@FormParam("prodIdTxt")int pid, 
		@FormParam("prodNameTxt") String pname, 
		@FormParam("prodPriceTxt")double price){
		
		System.out.println(pid );
		System.out.println(pname);
		System.out.println(price);
	}
	
	
}
