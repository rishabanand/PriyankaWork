package com.cg.webservice.controller;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path(value="/payment")
public class PaymentController {

	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String printHello(){
		return "Hello";
	}
	
	@POST
	public void printMessage(){
		System.out.println("Hello World");
	}
}
