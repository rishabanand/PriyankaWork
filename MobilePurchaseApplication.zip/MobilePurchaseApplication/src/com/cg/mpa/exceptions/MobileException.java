package com.cg.mpa.exceptions;

public class MobileException extends Exception {

	public MobileException() {
		
	}

	public MobileException(String message) {
		super(message);
		
	}

	public MobileException(Throwable cause) {
		super(cause);
		
	}

	public MobileException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public MobileException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

}
