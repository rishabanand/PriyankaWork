package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.Trainee;
import com.cg.spring.dao.TraineeRepository;
@Transactional
@Service
public class TraineeserviceImpl implements TraineeService{
	@Autowired
	  TraineeRepository repository;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		
		return repository.addTrainee(trainee);
	}

	@Override
	public Trainee getTraineeDetails(int traineeid) {
		
		return repository.getTraineeDetails(traineeid);
	}

	@Override
	public Trainee deleteTrainee(int traineeid) {
		return repository.deleteTrainee(traineeid);
	}

	@Override
	public List<Trainee> getTraineeList() {
		
		return repository.getTraineeList();
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		
		return repository.updateTrainee(trainee);
	}

}
