package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.bean.Trainee;



public interface TraineeRepository {
	public Trainee addTrainee(Trainee trainee);
	public Trainee getTraineeDetails(int traineeid);
	public Trainee deleteTrainee(int traineeid);
	public List<Trainee> getTraineeList();
	public Trainee updateTrainee(Trainee trainee);
}
