package com.cg.spring.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.bean.Trainee;


@Repository
public class TraineeImpl implements TraineeRepository{
	@PersistenceContext
	EntityManager entityManager;


	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
		
	}


	@Override
	public Trainee deleteTrainee(int traineeid) {
		Trainee trainee=getTraineeDetails(traineeid);
		entityManager.remove(trainee);
		entityManager.flush();
		return trainee;
		
	}


	@Override
	public Trainee getTraineeDetails(int traineeid) {
		Trainee	 trainee=entityManager.find(Trainee.class,traineeid);
		return trainee;
		
	}


	@Override
	public List<Trainee> getTraineeList() {
		List<Trainee> list;
		TypedQuery<Trainee> query=entityManager.createQuery("from Trainee",Trainee.class);
		list=query.getResultList();
		return list;
		
	}


	@Override
	public Trainee updateTrainee(Trainee trainee) {
		entityManager.merge(trainee);
		entityManager.flush();
		return trainee;
	}

}
