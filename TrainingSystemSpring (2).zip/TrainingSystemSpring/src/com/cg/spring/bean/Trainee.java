package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="trainee")
//@SequenceGenerator(name="trainee_id_sequence",sequenceName="traineeid_seq")
public class Trainee {
	//@NotNull
	@Id
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="trainee_id_sequence")
	@Column(name="trainee_id")
	
	private int traineeId;
	@NotEmpty(message="trainee name cannot be blank")
	@Size(max=20,min=5,message="Length >=5 and <=20 chars")
	@Column(name="trainee_name")
	private String traineeName;
	@NotEmpty(message="trainee domain cannot be blank")
	@Column(name="trainee_domain")
	private String traineeDomain;
	@NotEmpty(message="trainee location cannot be blank")
	@Column(name="trainee_location")
	private String traineeLocation;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

}
