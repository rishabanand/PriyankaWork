package com.cg.demotwojpa.service;

import java.util.List;

import com.cg.demotwojpa.dto.Project;

public interface IProjectService {
	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
	//public int updateProject(int  projId);
	public List<Project> showAllproject();
	public void updateProject(Project pro);
	
}
