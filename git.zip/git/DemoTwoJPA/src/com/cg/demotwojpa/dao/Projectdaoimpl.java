package com.cg.demotwojpa.dao;

import java.util.List;

import javax.persistence.EntityManager;





import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.demotwojpa.dto.Project;

public class Projectdaoimpl implements IProjectDao{
	EntityManager em;
	
 public Projectdaoimpl() {
	em=ProjectUtil.getEntityManager();
}	

	@Override
	public int addProject(Project proj) {
		em.getTransaction().begin();
		em.persist(proj);
		em.getTransaction().commit();
		return proj.getProjectId();
		
	}

	@Override
	public void removeProject(int projId) {
//		em.getTransaction().begin();
//		Project premove=em.find(Project.class,projId);
//        em.remove(premove);
//		em.getTransaction().commit();
		em.getTransaction().begin();
		Query queryRemove=em.createQuery("DELETE from Project where projectId=:pid");
		queryRemove.setParameter("pid", projId);
		queryRemove.executeUpdate();
		em.getTransaction().commit();
	}

	@Override
	public Project findProject(int projId) {
		em.getTransaction().begin();
		   Project pfind=em.find(Project.class,projId);
				em.close();
				return pfind;
			
		
	
	}

	@Override
	public int updateProject(int projId) {
//		em.getTransaction().begin();
//		Project pupdate=em.find(Project.class,1001);
//		pupdate.setProjectName("abcdef");
//		pupdate.setProjectDepartment("ADMIN");
//		em.merge(pupdate);
//		em.getTransaction().commit();
//		em.close();
		
		return 0;
	}

	@Override
	public List<Project> showAllproject() {
		//Query queryone=em.createQuery("FROM Project");
		//TypedQuery<Project> queryone=em.createQuery("FROM Project",Project.class);
		Query queryone=em.createNamedQuery("getALLData");
		List<Project> mylist=queryone.getResultList();
		return mylist;
	}

	@Override
	public void updateProject(Project pro) {
		em.getTransaction().begin();
		Query queryupdate=em.createQuery("UPDATE Project SET  projectName=:pname,projectDepartment=:dname where projectId=:pid");
		queryupdate.setParameter("pid",pro.getProjectId());
		queryupdate.setParameter("pname",pro.getProjectName());
		queryupdate.setParameter("dname",pro.getProjectDepartment());
		queryupdate.executeUpdate();
		em.getTransaction().commit();
	}

	
	

}
