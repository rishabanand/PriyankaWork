package com.cg.spring.basic.ui;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.spring.basic.bean.Employee;

public class client {
	public static void main(String[] args) {
		//Resource resource=new ClassPathResource("beans.xml");
		//XmlBeanFactory factory=new XmlBeanFactory(resource);
		//Employee emp=(Employee) factory.getBean("emp");
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		Employee emp=(Employee) context.getBean("emp");
		System.out.println(emp.getEmpName());
		System.out.println(emp.getDept());
		
	}

}
