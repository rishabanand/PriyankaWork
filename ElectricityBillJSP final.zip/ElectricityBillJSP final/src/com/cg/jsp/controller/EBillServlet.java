package com.cg.jsp.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




import com.cg.jsp.dto.Bill;
import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;
import com.cg.jsp.service.BillService;
import com.cg.jsp.service.BillServiceImpl;


@WebServlet(urlPatterns={"/list","/search","/show","/searchshow","/calculate"})
public class EBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public EBillServlet() {
        super();
        
    }
    public double CalculateUnitConsumed( double lastreading,double currentreading)
	{
		int fixedcharge=100;
		double unitconsumed = (lastreading-currentreading);
		double billamount =  (unitconsumed*1.15) + fixedcharge;
		return billamount;
     }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BillService service=new BillServiceImpl();
		String target="";
		String url=request.getServletPath();
		
		switch(url)
		{
		case "/list":

			try {
				
				List<Consumers> clist = service.getAllConsumers();
				System.out.println("query");
				request.setAttribute("clist",clist);
				target="CustomerList.jsp";
			} catch (BillException e) {
				String error=e.getMessage();
				request.setAttribute("error",error);
				target="Error.jsp";
				e.printStackTrace();
				
			}
			
		break;
		
		case "/search":
			
			String cid =request.getParameter("cid");
			try{	
				Consumers cons=service.getConsumers(Integer.parseInt(cid));
				HttpSession sess=request.getSession(true);
				sess.setAttribute("cons",cons);
				target="ShowConsumer.jsp";
		}catch(Exception e)
			{
			String error=e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
			}
			System.out.println("Ashpri");
		break;	
		
		
		case "/show":
			int id =Integer.parseInt(request.getParameter("cid"));
			HttpSession sess=request.getSession(true);
			sess.setAttribute("cno",id);
			try
			{
				System.out.println("hello");
		    List<Bill> blist = service.getAllDetails(id);
			System.out.println("query");
			request.setAttribute("blist",blist);
			
			System.out.println("priya");
			target="ShowBills.jsp";
		} catch (BillException e) {
			String error=e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
			System.out.println("hII I AM in catch");
			e.printStackTrace();
			
		}
			
			break;
			
		case "/searchshow":
			System.out.println("ppppp");
			int cno =Integer.parseInt(request.getParameter("id"));
			//int no =Integer.parseInt(request.getParameter("id"));
			//System.out.println(no);
			HttpSession sess1=request.getSession(true);
			sess1.setAttribute("cno",cno);
			try
			{
				System.out.println("hello1");
		    List<Bill> blist = service.getAllDetails(cno);
			System.out.println("query1");
			request.setAttribute("blist",blist);
			
			System.out.println("priya1");
			target="ShowBills.jsp";
		} catch (BillException e) {
			String error=e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
			System.out.println("hII I AM in catch");
			e.printStackTrace();
			
		}
			
			break;
		case "/calculate":
			
			int consumerno=Integer.parseInt(request.getParameter("consno"));
			double lastreading=Double.parseDouble(request.getParameter("lmmr"));
			double currentreading=Double.parseDouble(request.getParameter("cmmr"));
			double unitconsumed=currentreading-lastreading;
			System.out.println("calculate");
			
			try {
				if(currentreading>lastreading)
				{
					System.out.println("calculate2");
				double billAmt=CalculateUnitConsumed( lastreading, currentreading);
					Bill bill=new Bill(consumerno,currentreading,unitconsumed,billAmt);
				     service.addBillDetails(bill);
					request.setAttribute("bill", bill);
					Consumers cname=service.getConsumers(consumerno);
					HttpSession session=request.getSession(true);
					session.setAttribute("cust",cname);
					   target="BillInfo.jsp";
					   
						
				}		
					else
					{
						throw new BillException("Current Reading is less than that of last month");
					}
			} catch (BillException e) {
				request.setAttribute("error",e.getMessage());
			     target="Error.jsp";
				
			}
			
			
			break;
		}//end of switch
		
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request,response);
	}//end of do post

}//end of class
