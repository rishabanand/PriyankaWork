package com.cg.jsp.dao;

import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.cg.jsp.dto.Bill;
import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;

public class BillDaoImpl implements BillDao {
	Connection conn;
	public BillDaoImpl() {
		
	}

	@Override
	public List<Consumers> getAllConsumers() throws BillException {
		List<Consumers> clist = new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT consumer_num,consumer_name,address FROM Consumers";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				
				Consumers con= new Consumers();
				con.setConsumerNo(rst.getInt("consumer_num"));
				con.setConsumerName(rst.getString("consumer_name"));
				con.setAddress(rst.getString("address"));
				clist.add(con);
				
				
			}
		} catch (SQLException e) {
			throw new BillException("Problem in fetching mobile list");
			
		}
		
		
		return clist;
	}

	@Override
	public Consumers getDetails(int cid) throws BillException {
		String sql="SELECT consumer_num,consumer_name,address FROM Consumers WHERE consumer_num=?";
		Consumers cons=null;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,cid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				cons=new Consumers();
				cons.setConsumerNo(rst.getInt("consumer_num"));
				cons.setConsumerName(rst.getString("consumer_name"));
				cons.setAddress(rst.getString("address"));
				
			}
		} catch (SQLException e) {
			throw new BillException("Problem in fetching mobile data");
		}
		return cons;
		
	}

	

	@Override
	public List<Bill> getAllDetails(int bid) throws BillException {
		List<Bill> blist = new ArrayList<Bill>();
		conn=DBUtil.getConnection();
		String sql="SELECT bill_num, consumer_num,cur_reading,unitConsumed,netAmount,bill_date FROM BillDetails WHERE consumer_num=?";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,bid);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				System.out.println("dao");
				Bill bill= new Bill();
				bill.setBillNo(rst.getInt("bill_num"));
				bill.setConsumerNo(rst.getInt("consumer_num"));
				bill.setCurReading(rst.getDouble("cur_reading"));
				bill.setUnitCon(rst.getDouble("unitConsumed"));
				bill.setNetAmt(rst.getDouble("netAmount"));
				bill.setBillDate(rst.getDate("bill_date").toLocalDate());
				blist.add(bill);
				
				
			}
		} catch (SQLException e) {
			System.out.println("problem");
			throw new BillException("Problem in fetching bill details");
			
		}
		
		
		return blist;
	}

	@Override
	public int addBillDetails(Bill bill) throws BillException {
		
		String sql="INSERT INTO BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(seq_bill_num.nextval,?,?,?,?,?)";
		int ct=0;
		try {
			conn=DBUtil.getConnection();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1, bill.getConsumerNo());
			pst.setDouble(2,bill.getCurReading());
			pst.setDouble(3,bill.getUnitCon());
			pst.setDouble(4,bill.getNetAmt());
			LocalDate billdate=LocalDate.now();
			pst.setDate(5,Date.valueOf(billdate));
			ct=pst.executeUpdate();
			int r=pst.executeUpdate();
			int billid=0;
			if(r==1)
			{
			Statement st=conn.createStatement();
			 ResultSet rst=st.executeQuery("select seq_bill_num.currval from dual");
			 if(rst.next())
			 
				 billid=rst.getInt(1);
			 
			}
		} catch (SQLException e) 
		{
			throw new BillException("Customer Id does Not exist");
			
		}
		
		return ct;
	}

}
