package com.cg.jsp.service;

import java.util.List;
import com.cg.jsp.dto.Bill;
import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;


public interface BillService {
	List<Consumers> getAllConsumers() throws BillException;
	Consumers getConsumers(int cid) throws BillException;
	public List<Bill> getAllDetails(int bid) throws BillException;
	int addBillDetails(Bill bill) throws BillException;
}
