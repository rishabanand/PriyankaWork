package com.cg.dto;

import java.time.LocalDate;


public class Bill {

	private int billno;
	private int consno;
	private double meterread;
	private double unitcon;
	private double netamt;
	private LocalDate billdate;
	
	

	public Bill(int consno, double meterread, double unitcon,
			double netamt) {
		super();
		
		this.consno=consno;
		this.meterread = meterread;
		this.unitcon = unitcon;
		this.netamt = netamt;
		
	}

	public Bill() {
		
	}

	public int getBillno() {
		return billno;
	}

	public void setBillno(int billno) {
		this.billno = billno;
	}

	public int getConsno() {
		return consno;
	}

	public void setConsno(int consno) {
		this.consno = consno;
	}

	public double getMeterread() {
		return meterread;
	}

	public void setMeterread(double meterread) {
		this.meterread = meterread;
	}

	public double getUnitcon() {
		return unitcon;
	}

	public void setUnitcon(double unitcon) {
		this.unitcon = unitcon;
	}

	public double getNetamt() {
		return netamt;
	}

	public void setNetamt(double netamt) {
		this.netamt = netamt;
	}

	public LocalDate getBilldate() {
		return billdate;
	}

	public void setBilldate(LocalDate billdate) {
		this.billdate = billdate;
	}
	
	
}
