package com.cg.dto;

public class Consumer {

	private int consno;
	private String consname;
	private String address;
	
	public Consumer() {
	}

	

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}



	public String getConsname() {
		return consname;
	}



	public void setConsname(String consname) {
		this.consname = consname;
	}



	public int getConsno() {
		return consno;
	}



	public void setConsno(int consno) {
		this.consno = consno;
	}

	
}
