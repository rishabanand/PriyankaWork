package com.cg.service;

import java.util.List;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;

public interface BillService {

	public List<Consumer> getAllConsumers() throws BillException;
	Consumer getdetails(int cno) throws BillException;
	public Consumer SearchConsumers(int cn) throws BillException;
	public List<Bill> getAllBillDetails(int id) throws BillException;
	int insertBillDetail(Bill bill) throws BillException;
}
