package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.dao.DBUtil;
import com.cg.exception.BillException;
import com.cg.dao.BillDaoImpl;


public  class BillDaoImpl implements BillDao {
	Connection conn;
	   
	@Override
	public List<Consumer> getAllConsumers() throws BillException {
		
		List<Consumer> clist = new ArrayList<>();
		String sql = "Select * FROM Consumers";
		
		System.out.println("in dao");
		
		try {
			conn = DBUtil.getConnection();
		PreparedStatement pst= conn.prepareStatement(sql);
		ResultSet rst = pst.executeQuery();
		System.out.println("executeed"+rst);
		while(rst.next()){
			Consumer csr = new Consumer();
			csr.setConsno(rst.getInt(1));
			csr.setConsname(rst.getString(2));
			csr.setAddress(rst.getString(3));
			System.out.println("set");
			clist.add(csr);
		} 
	} catch (SQLException e) {
		throw new BillException("Problem in fetching list");
	}
  return clist;
}
	public Consumer getdetails(int cno) throws BillException {
		String sql="Select CONSUMER_NUM FROM CONSUMERS WHERE CONSUMER_NUM=?";
		Consumer Consumers=null;
		conn=DBUtil.getConnection();
		try {
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setInt(1,cno);
		ResultSet rst=pst.executeQuery();
		
		if(rst.next()){
			Consumer Consumer = new Consumer();
			Consumer.setConsno(rst.getInt("CONSUMER_NUM"));
		}
	} catch(SQLException e) {
		throw new BillException("Problem in fetching mobile data ");
	}
		return Consumers;
	}
	public Consumer SearchConsumers(int cn) throws BillException {
		Consumer cons = new Consumer();
		String sql="Select CONSUMER_NUM,CONSUMER_NAME,ADDRESS FROM CONSUMERS WHERE CONSUMER_NUM=?";
		
		
		try {
			conn=DBUtil.getConnection();
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setInt(1,cn);
		ResultSet rst=pst.executeQuery();
		
		if(rst.next()){
			
			cons.setConsno(rst.getInt("CONSUMER_NUM"));
			cons.setConsname(rst.getString("CONSUMER_NAME"));
			cons.setAddress(rst.getString("ADDRESS"));
		}
	} catch(SQLException e) {
		throw new BillException("Problem in fetching mobile data ");
	}
		return cons;
	}
	@Override
	public List<Bill> getAllBillDetails(int cno) throws BillException {
		
		String sql = "Select * FROM BillDetails where CONSUMER_NUM=?";
		List<Bill> blist = new ArrayList<Bill>();
		Bill res=null;
		
		
		try {
			conn = DBUtil.getConnection();
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setInt(1, cno);
		ResultSet rst = pst.executeQuery();
		System.out.println("executed query");
		while(rst.next()){
			res = new Bill();
			res.setBillno(rst.getInt(1));
			res.setConsno(rst.getInt(2));
			res.setMeterread(rst.getDouble(3));
			res.setUnitcon(rst.getDouble(4));
			res.setNetamt(rst.getDouble(5));
			res.setBilldate(rst.getDate(6).toLocalDate());
			System.out.println(res);
			
			
			blist.add(res);
		} 
	} catch (SQLException e) {
		throw new BillException("Problem in fetching list");
	}
  return blist;
}
	
	@Override
	public int insertBillDetail(Bill bill) throws BillException {
		int r=0;
		
		String insqry = "Insert into BillDetails (bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) values (seq_bill_num.nextval ,?,?,?,?,?)";
		int billNum=0;
		
		
		try {
		conn = DBUtil.getConnection();
		PreparedStatement pst= conn.prepareStatement(insqry);
		
		     pst.setInt(1,bill.getConsno());
			 pst.setDouble(2, bill.getMeterread());
			 pst.setDouble(3,bill.getUnitcon());
			 pst.setDouble(4,bill.getNetamt());
			 LocalDate billdate=LocalDate.now();
			 pst.setDate(5,Date.valueOf(billdate));
			 
			 r=pst.executeUpdate();
			 
			 if(r==1){
				 Statement st=conn.createStatement();
				 ResultSet rs=st.executeQuery("select seq_bill_num.currval from dual");
				 if(rs.next())
					 billNum=rs.getInt(1);
				 else
					 
		throw new BillException("Consumer no does not exist");
	}
		} catch (SQLException e) {
			
			throw new BillException("Consumer no does not exist");
		}
  return billNum;
}
}
