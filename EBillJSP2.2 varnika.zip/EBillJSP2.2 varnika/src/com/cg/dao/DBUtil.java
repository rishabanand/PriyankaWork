package com.cg.dao;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.cg.exception.BillException;

	public class DBUtil {

		private static Connection conn;
		public static Connection getConnection() throws BillException{
		if(conn == null)
		{
			try {
		          InitialContext ic = new InitialContext();
		          DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
				 conn = ds.getConnection();
			   } catch(NamingException e) {
		    	 throw new BillException("Problem in obtaining data source "+e.getMessage());
		     } catch(SQLException e) {
		    	 throw new BillException("Problem in obtaining Connection "+e.getMessage());
		     }
	}
		return conn;
	}
	}
