package com.cg.dao;

import java.util.List;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;


public interface BillDao {

	List<Consumer> getAllConsumers() throws BillException;
	Consumer getdetails(int cno) throws BillException;
	Consumer SearchConsumers(int cn) throws BillException;
	List<Bill> getAllBillDetails(int bid) throws BillException;
	int insertBillDetail(Bill bill) throws BillException; 
}
