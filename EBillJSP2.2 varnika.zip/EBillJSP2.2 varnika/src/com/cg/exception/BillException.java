package com.cg.exception;

public class BillException extends Exception {

	public BillException() {
	}

	public BillException(String message) {
		super(message);
	}

	public BillException(Throwable cause) {
		super(cause);
	}

	public BillException(String message, Throwable cause) {
		super(message, cause);
	}

	public BillException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
}

