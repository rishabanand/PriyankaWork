package com.cg.loanapp.ui;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.PropertyConfigurator;

import java.util.Scanner;

import com.cg.loanapp.bean.Customer;
import com.cg.loanapp.bean.Loan;
import com.cg.loanapp.exception.LoanException;
import com.cg.loanapp.service.ILoanService;
import com.cg.loanapp.service.LoanService;
import com.cg.loanapp.service.ValidationService;
import com.cg.loanapp.service.ValidationServiceI;



public class Client {
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Logger logger=Logger.getLogger(Client.class);
		
		Customer cust=new Customer();
		Loan loan=new Loan();
		ValidationService validation=new ValidationServiceI();
		ILoanService service= new LoanService();
		Scanner sc= new Scanner(System.in);
		
		int option=0;
		do
		{
			System.out.println("XYZ Finance Company welcomes you");
			System.out.println("\n\n1.Add Customer Details ...");
			System.out.println("2.Exit");
			System.out.println("Enter Your Choice .");
			 option= sc.nextInt();
			 
			switch(option)
			{
			case 1:
				
				do{
					System.out.println("Enter Customer Name : ");
					logger.info("Enter Customer Name");
					String name=sc.next();
					boolean res=validation.validateCustomerName(name);
					if(res==true)
					{
						cust.setCustName(name);
						break;
					}
					else
						System.out.println("Name should contain only alphabets");
					logger.info("Name should contain only alphabets");
					}while(true);
				
				do{
					System.out.println("Enter Address : ");
					String address=sc.next();
					cust.setAddress(address);
						break;
					
				}while(true);
					do{
					System.out.println("Enter Mail id : ");
					String mailid= sc.next();
					boolean res= validation.validateMailId(mailid);
					if(res==true)
						{
							cust.setEmail(mailid);
							break;
						}
						else
							System.out.println("Mail id as: abcd@capgemini.com ");
					        logger.info("Mail id as: abcd@capgemini.com ");
					}while(true);
					do{
						System.out.println("Enter mobile No :");
						Long mobno= sc.nextLong();
					    cust.setMobile(mobno);
							break;
						}while(true);
					
					
					try {
						long Cust_id= service.insertCust(cust);
						System.out.println("Customer Information saved Successfully.Your CustomerId is: "+Cust_id  );
						logger.info("Customer Information saved Successfully.Your CustomerId is: "+Cust_id );
					} catch (LoanException e) {
						System.out.println(e.getMessage());
						logger.error(e.getMessage());
						
					}
				
					System.out.println("Do You wish to apply For Loan");
					System.out.println("1.Yes");
					System.out.println("2.Exit");
					System.out.println("Enter Your Choice");
					option=sc.nextInt();
					switch(option)
					
					{
					case 1:
						System.out.println("Enter Your CustomerId");
						long custid=sc.nextLong();
						System.out.println("Enter The Loan Amount");
						logger.info("Enter The Loan Amount");
					    Double loanamt=sc.nextDouble();
					    System.out.println("Enter The Loan Duration");
					    Integer duration=sc.nextInt();
					    logger.info("Enter The Loan Duration");
						
					    try {
							double EMI=service.calculateEMI(loanamt, duration);
               System.out.println("For loan Amount"+loanamt+" and"+duration+" Years Duration."
									
									+ "Your EMI per Month will be"+EMI );
              
					    System.out.println("Do You Want To apply for loan");
			               System.out.println("Option 1 for Loan");
			               System.out.println("Option 2 for exit");
			               System.out.println("Enter Your Choice"); 
					   Integer choice1=sc.nextInt();
                   switch(choice1)
                   {
                   case 1:
                	   long loanid=service.applyLoan(loan);
                	   
                	   loan.setLoanAmount(loanamt);
					   loan.setCustId(custid);
					  loan.setDuration(duration);
	                  System.out.println("Loan Id is generated");               
					    				    					    
					    break;
					case 2:
					    default :System.out.println("Thanks For the Service ");	
					    logger.info("Thanks For the Service");       
			     break;
                   }

					} catch (LoanException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}break;
              //end of switch choice1
			    case 2:
				default :System.out.println("please enter correct option ");	
					    
					}//end of switch
			}//end of switch
		
		}while(option!=2);//end of while
		
		
			
		
	}//end of main

}//end of class
