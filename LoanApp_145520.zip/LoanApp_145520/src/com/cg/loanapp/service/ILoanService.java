package com.cg.loanapp.service;

import com.cg.loanapp.bean.Customer;
import com.cg.loanapp.bean.Loan;
import com.cg.loanapp.exception.LoanException;

public interface ILoanService {
	
	public long applyLoan(Loan loan) throws LoanException;
	public Customer validateCustomer(Customer customer)throws LoanException;
	public long insertCust(Customer cust)throws LoanException;
	public double calculateEMI(double amount,int duration)throws LoanException;

	

}
