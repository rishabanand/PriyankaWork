package com.cg.loanapp.service;

public interface ValidationService {
	public boolean validateCustomerName(String name);
	public boolean validateAddress(String address);
	public boolean validateMailId(String mailid);
	//public boolean validateMobileNo(Long mobno);

}
