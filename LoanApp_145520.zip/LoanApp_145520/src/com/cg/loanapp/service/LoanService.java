package com.cg.loanapp.service;

import com.cg.loanapp.bean.Customer;
import com.cg.loanapp.bean.Loan;
import com.cg.loanapp.dao.ILoanDao;
import com.cg.loanapp.dao.LoanDao;
import com.cg.loanapp.exception.LoanException;


public class LoanService implements ILoanService {
	
	ILoanDao dao;
	
	public LoanService()
	{
		dao=new LoanDao();
	}

	

	
	
	@Override
	public long insertCust(Customer cust)throws LoanException {
		
		return dao.insertCust(cust);
	}

	@Override
	public double calculateEMI(double amount, int duration)throws LoanException {
		return dao.calculateEMI(amount, duration);
		
		
	}







	@Override
	public Customer validateCustomer(Customer customer) throws LoanException {
		return customer;
		
	}





	@Override
	public long applyLoan(Loan loan) throws LoanException {
		return dao.applyLoan(loan);
	}

}
