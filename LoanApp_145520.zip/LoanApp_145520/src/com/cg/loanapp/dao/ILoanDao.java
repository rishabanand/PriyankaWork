package com.cg.loanapp.dao;

import com.cg.loanapp.bean.Customer;
import com.cg.loanapp.bean.Loan;
import com.cg.loanapp.exception.LoanException;

public interface ILoanDao {
	public long applyLoan(Loan loan) throws LoanException;
	public long insertCust(Customer cust) throws LoanException;
    public double calculateEMI(double amount,int duration) throws LoanException;
	//long applyLoan(Loan loan) throws LoanException;
}
