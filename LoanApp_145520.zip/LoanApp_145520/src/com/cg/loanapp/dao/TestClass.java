package com.cg.loanapp.dao;

import org.junit.Assert;
import org.junit.Test;

import com.cg.loanapp.exception.LoanException;

public class TestClass {
	@Test
	public void testinputs()
	{
		ILoandao=new LoanDao();
		try
		{
			int list=dao.validateCustomer("10003",'Priyanka','Town','priyanka@capgemini.com',9087654321);
			Assert.assertTrue(list!=0);
		}catch(LoanException e)
		{
			e.printStackTrace();
		}
	}

}
