package com.cg.loanapp.util;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.FileInputStream;

public class DatabaseConnection {
	
	public static Connection getConnection()
	{
	Connection con=null;
	//Connection parameters
	
	String url;
	String user;
	String password;
	String driver;
	
	try{
		
		InputStream file= new FileInputStream("./resources/properties.properties");
		Properties prop=new Properties();
		prop.load(file);
		url=prop.getProperty("url");
		user=prop.getProperty("user");
		password=prop.getProperty("password");
		driver=prop.getProperty("driver");
		
		Class.forName(driver);
		con=DriverManager.getConnection(url,user,password);
		System.out.println("database connected...");
		file.close();
			
	} catch (ClassNotFoundException e){
		System.out.println("Driver class not loaded");
	}
	catch(SQLException e)
	{
		System.out.println("error while connecting DB");
	}
	catch(IOException e)
	{
		System.out.println(e.getMessage());
	} 
	return con;
}

	public static void main(String[] args)
	{
		getConnection();

}
}