package com.cg.loanapp.exception;

public class LoanException extends Exception{
	public  LoanException(String msg)
	{
		super(msg);
	}

}
