package com.cg.mpa.service;

import com.cg.mpa.dto.Mobile;

import java.util.List;



import com.cg.mpa.exceptions.MobileException;

public interface MobilePurchaseService {
	List<Mobile> getAllMobiles() throws MobileException;

}
