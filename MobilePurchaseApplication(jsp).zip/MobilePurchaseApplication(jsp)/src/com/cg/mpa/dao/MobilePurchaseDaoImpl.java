package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.cg.mpa.dto.Mobile;
import com.cg.mpa.exceptions.MobileException;

public class MobilePurchaseDaoImpl implements MobilePurchaseDao {

	Connection conn;

	@Override
	public List<Mobile> getAllMobiles() throws MobileException {
		List<Mobile> mlist = new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT mobileid,name,price,quantity FROM mobiles";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				Mobile m= new Mobile();
				m.setMobileid(rst.getInt("mobileid"));
				m.setMobileName(rst.getString("name"));
				m.setPrice(rst.getDouble("price"));
				m.setQuantity(rst.getInt("quantity"));
				mlist.add(m);
			}
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching mobile list");
			
		}
		
		
		return mlist;
	}

}
