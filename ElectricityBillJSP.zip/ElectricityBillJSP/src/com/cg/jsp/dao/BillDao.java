package com.cg.jsp.dao;

import java.util.List;

import com.cg.jsp.dto.Bill;
import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;



public interface BillDao {
	List<Consumers> getAllConsumers() throws BillException;
	Consumers getDetails(int cid) throws BillException;
	Bill getBillDetails(int bid) throws  BillException;
}
