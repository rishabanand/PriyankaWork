package com.cg.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.jsp.dto.Bill;
import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;

public class BillDaoImpl implements BillDao {
	Connection conn;
	public BillDaoImpl() {
		
	}

	@Override
	public List<Consumers> getAllConsumers() throws BillException {
		List<Consumers> clist = new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT consumer_num,consumer_name,address FROM Consumers";
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				System.out.println("in dao before query");
				Consumers con= new Consumers();
				con.setConsumerNo(rst.getInt("consumer_num"));
				con.setConsumerName(rst.getString("consumer_name"));
				con.setAddress(rst.getString("address"));
				clist.add(con);
				System.out.println("exected");
				
			}
		} catch (SQLException e) {
			throw new BillException("Problem in fetching mobile list");
			
		}
		
		
		return clist;
	}

	@Override
	public Consumers getDetails(int cid) throws BillException {
		String sql="SELECT consumer_num,consumer_name,address FROM Consumers WHERE consumer_num=?";
		Consumers cons=null;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,cid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				cons=new Consumers();
				cons.setConsumerNo(rst.getInt("consumer_num"));
				cons.setConsumerName(rst.getString("consumer_name"));
				cons.setAddress(rst.getString("address"));
				
			}
		} catch (SQLException e) {
			throw new BillException("Problem in fetching mobile data");
		}
		return cons;
		
	}

	@Override
	public Bill getBillDetails(int bid) throws BillException {
		String sql="SELECT bill_num, consumer_num,cur_reading,unitConsumed,netAmount FROM BillDetails WHERE consumer_num=?";
		Bill bill=null;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setInt(1,bid);
			ResultSet rst=pst.executeQuery();
			if(rst.next())
			{
				bill=new Bill();
				bill.setBillNo(rst.getInt("bill_num"));
				bill.setConsumerNo(rst.getInt("consumer_num"));
				bill.setCurReading(rst.getDouble("cur_reading"));
				bill.setUnitCon(rst.getDouble("unitConsumed"));
				bill.setNetAmt(rst.getDouble("netAmount"));
				
			}
		} catch (SQLException e) {
			throw new BillException("Problem in fetching mobile data");
		}
		return bill;
		
	}

}
