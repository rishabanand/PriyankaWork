package com.cg.jsp.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.jsp.dto.Consumers;
import com.cg.jsp.exceptions.BillException;
import com.cg.jsp.service.BillService;
import com.cg.jsp.service.BillServiceImpl;


@WebServlet(urlPatterns={"/list","/search"})
public class EBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public EBillServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BillService service=new BillServiceImpl();
		String target="";
		String url=request.getServletPath();
		
		switch(url)
		{
		case "/list":

			try {
				System.out.println("i m in try");
				List<Consumers> clist = service.getAllConsumers();
				System.out.println("query");
				request.setAttribute("clist",clist);
				target="CustomerList.jsp";
			} catch (BillException e) {
				String error=e.getMessage();
				request.setAttribute("error",error);
				target="Error.jsp";
				System.out.println("hII I AM in catch");
				e.printStackTrace();
				
			}
			System.out.println("priya");
		break;
		
		case "/search":
			
			String cid =request.getParameter("cid");
			try{	
				Consumers cons=service.getConsumers(Integer.parseInt(cid));
				HttpSession sess=request.getSession(true);
				sess.setAttribute("cons",cons);
				target="ShowConsumer.jsp";
		}catch(Exception e)
			{
			String error=e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
			}
			System.out.println("Ashpri");
		break;	
		}//end of switch
		
		RequestDispatcher disp=request.getRequestDispatcher(target);
		disp.forward(request,response);
	}//end of do post

}//end of class
