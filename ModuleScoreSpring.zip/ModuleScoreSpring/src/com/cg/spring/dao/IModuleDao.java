package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.bean.AssessmentScore;
import com.cg.spring.bean.Trainees;

public interface IModuleDao {
	public List<Trainees> getTraineeList();
	public AssessmentScore addAssessment(AssessmentScore score);

}
