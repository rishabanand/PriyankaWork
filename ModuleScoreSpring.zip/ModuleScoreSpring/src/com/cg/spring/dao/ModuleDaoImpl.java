package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.bean.AssessmentScore;
import com.cg.spring.bean.Trainees;

@Repository
public class ModuleDaoImpl implements IModuleDao{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Trainees> getTraineeList() {
		List<Trainees> tlist;
		TypedQuery<Trainees> query=entityManager.createQuery("from Trainees",Trainees.class);
		tlist=query.getResultList();
		return tlist;
		
	}

	@Override
	public AssessmentScore addAssessment(AssessmentScore score) {
		entityManager.persist(score);
		entityManager.flush();
		return score;
		
	}
}
