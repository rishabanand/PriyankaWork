package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.AssessmentScore;
import com.cg.spring.bean.Trainees;
import com.cg.spring.dao.IModuleDao;

@Transactional
@Service
public class ModuleServiceImpl implements IModuleService{

	@Autowired
	IModuleDao dao;

	@Override
	public List<Trainees> getTraineeList() {
	
		return dao.getTraineeList();
	}

	@Override
	public AssessmentScore addAssessment(AssessmentScore score) {
	
		int grade=CalculateGrade(score);
		score.setGrade(grade);
		return dao.addAssessment(score);
	}

	@Override
	public int CalculateGrade(AssessmentScore score) {
		int mpt=score.getMpt();
		System.out.println(mpt);
		int mtt=score.getMtt();
		int assMarks=score.getAssMarks();
		int total=mpt+mtt+assMarks;
		score.setTotalNumber(total);
		System.out.println("total is"+total);
		int grade=0;
		if((total>0) && (total<=49)){
			grade= 0;
	}
	else if((total>50) && (total<=59))
	{
		grade=1;
	}
	else if((total>60) && (total<=69)) 
	{
		grade=2;
	}
	else if((total>70) && (total<=79)) 
	{
		grade=3;
	}
	else if((total>80) && (total<=89)) 
	{
		grade=4;
	}
	else if((total>90) && (total<=100)) 
	{
		grade=5;
	}
		return grade;
	}

	
}
