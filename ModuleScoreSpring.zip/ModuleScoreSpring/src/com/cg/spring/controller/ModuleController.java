package com.cg.spring.controller;

import java.util.List;




import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.bean.AssessmentScore;
import com.cg.spring.bean.Trainees;
import com.cg.spring.service.IModuleService;

@Controller
public class ModuleController {
	@Autowired
	IModuleService service;
	
	
	@RequestMapping("/addAssessmentPage")
	public String AddAssesmentPage(Model model)
	{
		System.out.println("trainee");
		AssessmentScore score=new AssessmentScore();
		model.addAttribute("score",score);
	List<Trainees> tlist=service.getTraineeList();
	    model.addAttribute("traineeList",tlist);
		return "Add";
		
	}
	
	@RequestMapping("/insertdetail")
	public String AddAssesmentDetails(Model model,@Valid @ModelAttribute("score") AssessmentScore score,BindingResult result)
	{
		if(result.hasErrors())
		{
			return "Add";
		}
		else
		{
		score=service.addAssessment(score);
	    model.addAttribute("score",score);
		return "Success";
		}
		
	}
	

}
