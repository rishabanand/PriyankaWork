package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
//@Table(name="assessmentscore")
@SequenceGenerator(name="s_no_sequence",sequenceName="sno_seq")
public class AssessmentScore {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="s_no_sequence")
	private int sNo;
	
	public int getsNo() {
	return sNo;
}
public void setsNo(int sNo) {
	this.sNo = sNo;
}
	//@Column(name="trainee_id")
	private int traineeId;
	//@Column(name="module_name")
	private String moduleName;
	//@Column(name="mpt")
	@Max(value=60,message="Marks Should be mpt<=60")
	@Min(value=0,message="Marks should be mpt>=0")
	private int mpt;
	//@Column(name="mtt")
	@Max(value=15,message="Marks Should be mtt<=15")
	@Min(value=0,message="Marks should be mtt>=0")
	private int mtt;
	//@Column(name="ass_marks")
	@Max(value=15,message="Marks Should be assMarks<=15")
	@Min(value=0,message="Marks should be assMarks>=0")
	private int assMarks;
	//@Column(name="total")
	private int totalNumber;
	//@Column(name="grade")
	private int grade;
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public int getMpt() {
		return mpt;
	}
	public void setMpt(int mpt) {
		this.mpt = mpt;
	}
	public int getMtt() {
		return mtt;
	}
	public void setMtt(int mtt) {
		this.mtt = mtt;
	}
	public int getAssMarks() {
		return assMarks;
	}
	public void setAssMarks(int assMarks) {
		this.assMarks = assMarks;
	}
	public int getTotalNumber() {
		return totalNumber;
	}
	public void setTotalNumber(int totalNumber) {
		this.totalNumber = totalNumber;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	
	
	

}
