package com.cg.jpa.ui;

import com.cg.jpa.dto.Author;
import com.cg.jpa.service.AuthorServiceImpl;
import com.cg.jpa.service.IAuthorService;

public class MyMain {
	public static void main(String[] args) {
		IAuthorService service=new AuthorServiceImpl();
		Author author=new Author();
		author.setAuthorId(1001);
		author.setFirstName("ramesh");
		author.setMiddleName("kumar");
		author.setLastName("sayal");
		author.setPhoneNo(9087654);
		service.addauthor(author);
		service.deleteauthor(1001);
		Author find=service.findauthor(1001);
	    System.out.println("First Name"+find.getFirstName());
	    System.out.println("Middle Name:"+find.getMiddleName());
		System.out.println("Last Name:"+find.getLastName());
		System.out.println("Phone No:"+find.getPhoneNo());
		service.updateauthor(1001);
		
	}

}
