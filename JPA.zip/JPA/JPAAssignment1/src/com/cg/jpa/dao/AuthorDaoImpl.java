package com.cg.jpa.dao;

import javax.persistence.EntityManager;
import com.cg.jpa.dto.Author;

public class AuthorDaoImpl implements IAuthorDao {
	EntityManager em;
	
	 public AuthorDaoImpl() {
		em=DBUtil.getEntityManager();
	}	

	@Override
	public int addauthor(Author author) {
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();
		return 0;
	}

	@Override
	public int updateauthor(int id) {
		em.getTransaction().begin();
		Author aupdate=em.find(Author.class,1001);
		aupdate.setFirstName("ronit");
		aupdate.setMiddleName("kumar");
		aupdate.setLastName("seth");
		aupdate.setPhoneNo(908765);
		em.merge(aupdate);
		em.getTransaction().commit();
		em.close();
		
		return 0;
	}

	@Override
	public int deleteauthor(int id) {
		em.getTransaction().begin();
		Author aremove=em.find(Author.class,1001);
        em.remove(aremove);
		em.getTransaction().commit();
		return 0;
	}

	@Override
	public Author findauthor(int id) {
		em.getTransaction().begin();
	    Author afind=em.find(Author.class,1001);
			em.close();
			return afind;
		
	}


}
