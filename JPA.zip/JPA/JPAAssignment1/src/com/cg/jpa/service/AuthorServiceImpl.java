package com.cg.jpa.service;

import com.cg.jpa.dao.AuthorDaoImpl;
import com.cg.jpa.dao.IAuthorDao;
import com.cg.jpa.dto.Author;

public class AuthorServiceImpl implements IAuthorService {
	IAuthorDao dao=new AuthorDaoImpl();

	@Override
	public int addauthor(Author author) {
		return dao.addauthor(author);
		
	}

	@Override
	public int updateauthor(int id) {
		
		return dao.updateauthor(id);
	}

	@Override
	public int deleteauthor(int id) {
		
		return dao.deleteauthor(id);
	}

	@Override
	public Author findauthor(int id) {
		return dao.findauthor(id);
	}

}
