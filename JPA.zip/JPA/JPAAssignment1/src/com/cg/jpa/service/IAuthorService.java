package com.cg.jpa.service;

import com.cg.jpa.dto.Author;

public interface IAuthorService {
	public int addauthor(Author author);
	public int updateauthor(int id);
	public int deleteauthor(int id);
	public Author findauthor(int id);
	

}
