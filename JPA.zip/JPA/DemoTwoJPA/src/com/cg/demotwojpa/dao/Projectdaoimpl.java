package com.cg.demotwojpa.dao;

import javax.persistence.EntityManager;




import com.cg.demotwojpa.dto.Project;

public class Projectdaoimpl implements IProjectDao{
	EntityManager em;
	
 public Projectdaoimpl() {
	em=ProjectUtil.getEntityManager();
}	

	@Override
	public int addProject(Project proj) {
		em.getTransaction().begin();
		em.persist(proj);
		em.getTransaction().commit();
		return 0;
		
	}

	@Override
	public void removeProject(int projId) {
		em.getTransaction().begin();
		Project premove=em.find(Project.class,1001);
        em.remove(premove);
		em.getTransaction().commit();
		
	}

	@Override
	public Project findProject(int projId) {
		em.getTransaction().begin();
    Project pfind=em.find(Project.class,1001);
		em.close();
		return pfind;
	}

	@Override
	public int updateProject(int projId) {
		em.getTransaction().begin();
		Project pupdate=em.find(Project.class,1001);
		pupdate.setProjectName("abcdef");
		pupdate.setProjectDepartment("ADMIN");
		em.merge(pupdate);
		em.getTransaction().commit();
		em.close();
		return 0;
	}

	
	

}
