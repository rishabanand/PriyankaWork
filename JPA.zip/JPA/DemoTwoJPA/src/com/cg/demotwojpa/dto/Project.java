package com.cg.demotwojpa.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="projectdb")
public class Project {
@Id
   @Column(name="proj_id")
	private int projectId;
  @Column(name="proj_name")
	private String projectName;
  @Column(name="proj_dep")
	private String projectDepartment;
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectDepartment() {
		return projectDepartment;
	}
	public void setProjectDepartment(String projectDepartment) {
		this.projectDepartment = projectDepartment;
	}

}
