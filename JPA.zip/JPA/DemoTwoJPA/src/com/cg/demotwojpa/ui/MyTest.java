package com.cg.demotwojpa.ui;

import com.cg.demotwojpa.dto.Project;
import com.cg.demotwojpa.service.IProjectService;
import com.cg.demotwojpa.service.ProjectServiceImpl;

public class MyTest {
	public static void main(String[] args) {
		IProjectService projectService=new ProjectServiceImpl();
		Project p=new Project();
		p.setProjectId(1001);
		p.setProjectName("ALFA LEVEL");
		p.setProjectDepartment("GE");
		projectService.addProject(p);
		projectService.removeProject(1001);
	    projectService.updateProject(1001);
	  Project pfind=projectService.findProject(1001);
		System.out.println("ID IS"+pfind.getProjectName());
		System.out.println("Name IS"+pfind.getProjectDepartment());
		
	}

}
