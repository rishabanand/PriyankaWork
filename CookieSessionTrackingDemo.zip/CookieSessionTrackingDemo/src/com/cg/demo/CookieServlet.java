package com.cg.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/CookieServlet")
public class CookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public CookieServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("uname");
		Cookie c=new Cookie("uname",uname);
		response.addCookie(c);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		out.print("<form action='CookieServlet1'>");
		out.print("ENTER Color:");
		out.print("<input type='text' name='color'/>");
		out.print("<input type='submit' name='Go'/>");
		out.print("</form>");
	}

}
