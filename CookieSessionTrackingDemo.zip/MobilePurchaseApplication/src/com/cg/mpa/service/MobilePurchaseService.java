package com.cg.mpa.service;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetails;

import java.util.List;




import com.cg.mpa.exceptions.MobileException;

public interface MobilePurchaseService {
	List<Mobile> getAllMobiles() throws MobileException;
	Mobile getMobile(int mid) throws MobileException;
	int insertPurchaseDetails(PurchaseDetails pDetail) throws MobileException;

}
