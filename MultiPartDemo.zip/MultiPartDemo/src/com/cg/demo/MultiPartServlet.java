package com.cg.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@	MultipartConfig(location="d:/person")
@WebServlet("/MultiPartServlet")
public class MultiPartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public MultiPartServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String uname=request.getParameter("uname");
		Part photo=request.getPart("photo");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.print(uname+",YOUR pHOTO UPLOADED successfully");
		
		photo.write(uname+".jpg");//file will be created with his uname
		Collection<String> headers=photo.getHeaderNames();
		for(String str:headers)
		out.print("<br/>"+str+":"+photo.getHeader(str));
	}

}
