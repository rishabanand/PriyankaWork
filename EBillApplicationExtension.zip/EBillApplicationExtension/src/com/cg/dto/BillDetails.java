package com.cg.dto;

import java.time.LocalDate;


public class BillDetails {
	private int bnum;  
	private int cnum; 
	private double curead; 
	private double unitconsumed;
	private double netamount; 
	private LocalDate billdate;
	public BillDetails(){}
	public BillDetails(int cnum,double curead,double unitconsumed,double netamount)
	{    this.bnum=bnum;
	     this.curead=curead;
	     this.unitconsumed=unitconsumed;
	     this.netamount=netamount; }
	public int getBnum() {
		return bnum;
	}
	public void setBnum(int bnum) {
		this.bnum = bnum;
	}
	
	
	public double getUnitconsumed() {
		return unitconsumed;
	}
	public void setUnitconsumed(double unitconsumed) {
		this.unitconsumed = unitconsumed;
	}
	public double getNetamount() {
		return netamount;
	}
	public void setNetamount(double netamount) {
		this.netamount = netamount;
	}
	public LocalDate getBilldate() {
		return billdate;
	}
	public void setBilldate(LocalDate billdate) {
		this.billdate = billdate;
	}
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public double getCuread() {
		return curead;
	}
	public void setCuread(double curead) {
		this.curead = curead;
	}
	
		
	}
	


