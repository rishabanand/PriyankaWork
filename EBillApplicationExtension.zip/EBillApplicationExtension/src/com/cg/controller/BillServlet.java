package com.cg.controller;

import java.io.IOException;







import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import com.cg.dto.BillDetails;


import com.cg.dto.Consumers;
import com.cg.exceptions.BillException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;


@WebServlet(urlPatterns={"/list","/view","/showdetails","/ShowConsumer","/calculate"})
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public BillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 
		EBillService eser=new EBillServiceImpl();
		String target="";
		String url=request.getServletPath();
		switch(url){
		case "/list":
			         try{
			        	 System.out.println("i m in front");
			            List<Consumers> clist=eser.getConsumerList();
			            
		                 request.setAttribute("clist", clist);
	                   	  target="ShowConsumerList.jsp";
	                 } catch(BillException e) {
		                // TODO Auto-generated catch block
	            	  //  String error=e.getMessage();
		                request.setAttribute("error", e.getMessage());
		                 target="Error.jsp";
	                  }break;

		case "/view":
			String cons=request.getParameter("cno");
			int no=Integer.parseInt(cons);
			HttpSession sess1=request.getSession(true);
			sess1.setAttribute("cno", no);
			try{
				 List<BillDetails> billlist=eser.getBills(no);
//				Consumers consumer=eser.SearchConsumer(no);
//				request.setAttribute("consumer", consumer);
				 request.setAttribute("billlist", billlist);
				target="ShowBills.jsp";
				
				
			}catch(BillException e)
			  {
				   //String error=e.getMessage();
	                request.setAttribute("error", e.getMessage()); 
	                target="Error.jsp";
			  }break;
	
		case "/showdetails":
			 String midStr=request.getParameter("mid");
			 int cno=Integer.parseInt(midStr);
			 HttpSession sess=request.getSession(true);
				sess.setAttribute("cno", cno);
			try{
				
				 List<BillDetails> billlist=eser.getBills(Integer.parseInt(midStr));
				 
				 request.setAttribute("billlist", billlist);
				  target="ShowBills.jsp";
			   }catch(BillException e)
			  {
				  // String error=e.getMessage();
	                request.setAttribute("error", e.getMessage()); 
	                target="Error.jsp";
			  }break;
		case "/ShowConsumer":
			int id=Integer.parseInt(request.getParameter("cNum"));
			try{
				Consumers consumer=eser.SearchConsumer(id);
				HttpSession sess2=request.getSession(true);
				sess2.setAttribute("consumer", consumer);
				//request.setAttribute("consumer", consumer);
				target="ShowConsumer.jsp";
				}catch(BillException e) {
	                // TODO Auto-generated catch block
            	   // String error=e.getMessage();
	                request.setAttribute("error", e.getMessage());
	                target="Error.jsp";
                  }break;
			
		case "/calculate":
			     System.out.println("in ebillservlet");
			      int cnum=Integer.parseInt(request.getParameter("cNum"));
                 double lastmeter=Double.parseDouble(request.getParameter("lMeter"));
    	         double  currmeter=Double.parseDouble(request.getParameter("cMeter"));
    	   try {
    		    	double netAmt=0;
        			double unitConsumed=0.0;
        			double fixedcharge=100;
    				     System.out.println("try block");
    				     unitConsumed=currmeter-lastmeter;
    				     Consumers con=eser.getConsumers(cnum);
    				     netAmt=(unitConsumed*1.15)+fixedcharge; 
    				      BillDetails bdetail=new BillDetails();
    			          bdetail.setCnum(cnum);
   	    	              bdetail.setCuread(currmeter);
   	    	              bdetail.setBilldate(LocalDate.now());
   	    	              bdetail.setNetamount(netAmt);
   	    	              bdetail.setUnitconsumed(unitConsumed);
   	    	              request.setAttribute("bdetail", bdetail);
   	    	 //target="ShowDetails.jsp";
   	    	 
       				  
     			          HttpSession session=request.getSession(true);
      				      session.setAttribute("con", con);
      				
       				  
        	    	      
        	    	       eser.insertbill(bdetail);
        	    	       target="ShowDetails.jsp";
        	    	      
    		    }
        		
    		    
    		    
   			 catch (Exception e) {
   				// TODO Auto-generated catch block
   				request.setAttribute("message", e.getMessage());
   				target="error.jsp";
   			}break;
		}
   		    RequestDispatcher disp=request.getRequestDispatcher(target);
			 disp.forward(request,response);
		         
				
		
}
}
    				 // HttpSession sess=request.getSession(true);
    				
    	/*			 BillDetails bdetail=new BillDetails(cnum, currmeter, unitConsumed, netAmt);
    				 eser.insertbill(bdetail);
    				 System.out.println("exec block");
    				 //sess.setAttribute("bdetail", bdetail);
    				
   				     Consumers consumer=eser.getConsumers(cnum);
    				
   				     System.out.println("session started");
// 				     HttpSession sess=request.getSession(true);
  				    
   				  
    	    	          	    	      
    	    	      
    	    	      target="ShowDetails.jsp";
    	    	      System.out.println("in done");
    	    	      
    				}
 
    			 catch (Exception e) {
    				// TODO Auto-generated catch block
    				request.setAttribute("message", e.getMessage());
    				target="error.jsp";
    			}break;
		}
		
    		    RequestDispatcher disp=request.getRequestDispatcher(target);
    			disp.forward(request,response);
    		         
    				
	}		
	}

			
      
       		
			
    	      
/*	          HttpSession sess=request.getSession(false);
	         
	         BillDetails bill=  (BillDetails) sess.getAttribute("bill");
	          bdetail.setCnum(bill.getCnum());
	          try{
                     
	        	 
 					{
 					
	        	     
 					}
				else
   					{
						
   					//throw new BillException("Customerid does not exist");}
	          catch(BillException e)
	          {String error=e.getMessage();
				request.setAttribute("error", error);
				target="error"; }
	          break;
		}*/
		
	


